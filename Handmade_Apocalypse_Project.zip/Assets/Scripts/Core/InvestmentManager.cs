﻿using UnityEngine;

public class InvestmentManager : MonoBehaviour
{
    public PlayerController player1;
    public PlayerController player2;

    public void InvestToken(PlayerController investingPlayer, PlayerController targetPlayer, int sphereIndex)
    {
        if (investingPlayer.SpendToken(1))
        {
            int investingIndex = (investingPlayer.playerName == "Player 1") ? 0 : 1;
            targetPlayer.incomingInvestments[sphereIndex, investingIndex]++;
            Debug.Log($"{investingPlayer.playerName} invested in {targetPlayer.playerName}'s sphere #{sphereIndex}");
        }
    }

    public void WithdrawToken(PlayerController investingPlayer, PlayerController targetPlayer, int sphereIndex)
    {
        int investingIndex = (investingPlayer.playerName == "Player 1") ? 0 : 1;

        if (targetPlayer.incomingInvestments[sphereIndex, investingIndex] > 0)
        {
            targetPlayer.incomingInvestments[sphereIndex, investingIndex]--;
            investingPlayer.tokens += 1;
            Debug.Log($"{investingPlayer.playerName} withdrew 1 token from sphere #{sphereIndex}");
        }
    }

    public void TickInvestments(PlayerController player)
    {
        for (int sphere = 0; sphere < 3; sphere++)
        {
            for (int investor = 0; investor < 2; investor++)
            {
                int tokens = player.incomingInvestments[sphere, investor];
                int quickDividends = tokens / 3;
                int slowTokens = tokens % 3;

                if (quickDividends > 0)
                {
                    if (investor == 0) player1.tokens += quickDividends;
                    else player2.tokens += quickDividends;

                    Debug.Log($"→ {quickDividends} token(s) paid to P{investor + 1} from sphere {sphere}");
                }

                // Slow payout every 3 turns
                if (slowTokens > 0)
                {
                    player.dividendCounter[sphere]++;

                    if (player.dividendCounter[sphere] >= 3)
                    {
                        if (investor == 0) player1.tokens += 1;
                        else player2.tokens += 1;

                        player.dividendCounter[sphere] = 0;

                        Debug.Log($"→ 1 slow token paid to P{investor + 1} from sphere {sphere}");
                    }
                }
            }
        }
    }

}
