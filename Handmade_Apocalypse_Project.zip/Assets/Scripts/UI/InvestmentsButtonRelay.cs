﻿using UnityEngine;
using TMPro;

public class InvestmentButtonRelay : MonoBehaviour
{
    public InvestmentManager investmentManager;
    public DevTools devTools;
    public PlayerController sphereOwner;
    public TokenUI tokenUI;
    public int sphereIndex;

    public TextMeshProUGUI amountLabel; // 👈 assign in Inspector

    public void OnPlusClicked()
    {
        investmentManager.InvestToken(devTools.targetPlayer, sphereOwner, sphereIndex);
        UpdateAmountText();
        Debug.Log("Plus clicked");
        tokenUI.UpdateDisplay();
    }

    public void OnMinusClicked()
    {
        investmentManager.WithdrawToken(devTools.targetPlayer, sphereOwner, sphereIndex);
        UpdateAmountText();
        Debug.Log("Minus clicked");
        tokenUI.UpdateDisplay();
    }

    public void UpdateAmountText()
    {
        int investorIndex = devTools.targetPlayer.playerName == "Player 1" ? 0 : 1;
        int value = sphereOwner.incomingInvestments[sphereIndex, investorIndex];
        amountLabel.text = value.ToString();
    }
}
