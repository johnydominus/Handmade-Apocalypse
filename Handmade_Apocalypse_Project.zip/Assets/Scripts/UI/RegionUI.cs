using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class RegionUI : MonoBehaviour
{
    public TextMeshProUGUI regionHeader;
    public GameObject emergencyPanel;
    public GameObject investmentPanel;

    public Image[] emergencyBars; // 0�10 fillAmount bars
    public TextMeshProUGUI[] emergencyLabels;

    public Button emergenciesTabButton;
    public Button investmentsTabButton;

    public TMP_Text emergenciesTabLabel;
    public TMP_Text investmentsTabLabel;

    private PlayerController currentPlayer;

    public void SetRegion(PlayerController player)
    {
        currentPlayer = player;
        Debug.Log($"Setting region panel to {player.playerName}");
        regionHeader.text = $"Region: {player.playerName}";
        UpdateEmergencyBars();
    }

    public void SwitchTab(string tab)
    {
        bool isEmergency = tab == "Emergencies";

        emergencyPanel.SetActive(isEmergency);
        investmentPanel.SetActive(!isEmergency);

        // Style the tab labels
        emergenciesTabLabel.fontStyle = isEmergency ? FontStyles.Bold : FontStyles.Normal;
        investmentsTabLabel.fontStyle = isEmergency ? FontStyles.Normal : FontStyles.Bold;

        emergenciesTabLabel.fontSize = isEmergency ? 16 : 15;
        investmentsTabLabel.fontSize = isEmergency ? 15 : 17;
    }

    public void UpdateEmergencyBars()
    {
        for (int i = 0; i < emergencyBars.Length; i++)
        {
            float level = currentPlayer.emergencyLevels[i];
            emergencyBars[i].fillAmount = level / 10f;
            emergencyLabels[i].text = $"{level}/10";

            if (currentPlayer.isEmergencyActive[i])
            {
                emergencyLabels[i].color = Color.red;
            }
            else
            {
                emergencyLabels[i].color = Color.black;
            }
        }
    }
}
