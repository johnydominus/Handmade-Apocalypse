﻿using TMPro;
using UnityEngine;

public class InvestmentForecastDisplay : MonoBehaviour
{
    public int sphereIndex; // 0 = Astro, 1 = Diplo, 2 = Med

    public TextMeshProUGUI oneTurnText;
    public TextMeshProUGUI twoTurnText;
    public TextMeshProUGUI threeTurnText;

    public RegionUI regionUI;    // 👈 Assigned in Inspector
    public DevTools devTools;    // 👈 Assigned in Inspector

    public void UpdateForecast(PlayerController sphereOwner, PlayerController investor)
    {
        int investorIndex = (investor == devTools.player1) ? 0 : 1;
        int tokens = sphereOwner.incomingInvestments[sphereIndex, investorIndex];

        int fast = tokens / 3;
        int slow = tokens % 3;

        oneTurnText.text = fast.ToString();
        twoTurnText.text = fast.ToString();
        threeTurnText.text = (fast * 3 + slow).ToString();
    }
}
