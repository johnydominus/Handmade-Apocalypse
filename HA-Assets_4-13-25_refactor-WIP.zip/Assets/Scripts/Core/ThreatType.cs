using UnityEngine;

public enum ThreatType
{
    Pandemic,
    NuclearWar,
    Asteroid,
    Hunger,
    DarkAges,
    ClimateChange
}
