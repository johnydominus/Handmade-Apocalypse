using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameServices gameServices;
    [SerializeField] private CardLibrary cardLibrary;

    private void Awake()
    {
        GameServices.Initialize(gameServices);
        
        gameServices.threatManager = new ThreatManager();
        gameServices.threatManager.Initialize();
        gameServices.cardSystem = new CardSystem();
        gameServices.cardSystem.Initialize(cardLibrary);

        GameEvents.OnGameInitialized.Raise();
    }
}
