using System.Collections.Generic;
using UnityEngine;

// This class is responsible for managing the card system, including drawing cards and managing the player's hand
public class CardSystem
{
    private CardLibrary cardLibrary;
    private List<CardData> playerHand = new List<CardData>();

    public void Initialize(CardLibrary library)
    {
        this.cardLibrary = library;
    }

    public CardData DrawCard(CardType type)
    {
        CardData card = cardLibrary.GetRandomCard(type);
        if (card == null) return null;

        if (type == CardType.PlayerAction)
            playerHand.Add(card);

        GameEvents.OnCardDrawn.Raise(card);
        return card;
    }

    public List<CardData> GetPlayerHand()
    {
        return playerHand;
    }

    public void ClearHand()
    {
        playerHand.Clear();
    }
}
