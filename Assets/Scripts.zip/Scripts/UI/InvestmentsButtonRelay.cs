﻿using UnityEngine;
using TMPro;

public class InvestmentButtonRelay : MonoBehaviour
{
    public InvestmentManager investmentManager;
    public PlayerController sphereOwner;
    public TokenUI tokenUI;
    public InvestmentForecastDisplay forecastDisplay;
    public int sphereIndex;

    public TextMeshProUGUI amountLabel; // 👈 assign in Inspector

    private PlayerController investor;

    public void SetContext(PlayerController sphereOwner, PlayerController investor)
    {
        this.sphereOwner = sphereOwner;
        this.investor = investor;
    }

    public void OnPlusClicked()
    {
        investmentManager.InvestToken(investor, sphereOwner, sphereIndex);
        UpdateAmountText();
        Debug.Log("Plus clicked");
        tokenUI.UpdateDisplay();
        forecastDisplay.UpdateForecast(sphereOwner, investor);
        Debug.Log("Forecast updated for sphere " + sphereIndex);
    }

    public void OnMinusClicked()
    {
        investmentManager.WithdrawToken(investor, sphereOwner, sphereIndex);
        UpdateAmountText();
        Debug.Log("Minus clicked");
        tokenUI.UpdateDisplay();
        forecastDisplay.UpdateForecast(sphereOwner, investor);
        Debug.Log("Forecast updated for sphere " + sphereIndex);
    }

    public void UpdateAmountText()
    {
        int investorIndex = (investor == TurnManager.Instance.player1) ? 0 : 1;
        int value = sphereOwner.incomingInvestments[sphereIndex, investorIndex];
        amountLabel.text = value.ToString();
    }
}
