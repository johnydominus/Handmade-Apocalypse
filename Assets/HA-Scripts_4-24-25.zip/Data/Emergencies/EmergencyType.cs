using UnityEngine;

public enum EmergencyType
{
    Epidemic,
    MartialLaw,
    FoodCrisis,
    EducationalCrisis,
    EcologicalCrisis
}
