using UnityEngine;

public enum SphereType
{
    All,
    Medicine,
    Diplomacy,
    Agriculture,
    EducationAndScience,
    Ecology,
    Astronautics,
    none
}
