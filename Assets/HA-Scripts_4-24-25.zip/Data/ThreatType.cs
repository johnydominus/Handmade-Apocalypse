using UnityEngine;

public enum ThreatType
{
    Pandemic,
    NuclearWar,
    Hunger,
    DarkAges,
    ClimateChange,
    Asteroid
}
