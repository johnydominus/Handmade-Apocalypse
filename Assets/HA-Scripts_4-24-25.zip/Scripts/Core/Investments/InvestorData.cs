using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;

public class InvestorData
{
    public int investedTokens;
    public List<int> slowDividendTimers = new List<int>();
}
